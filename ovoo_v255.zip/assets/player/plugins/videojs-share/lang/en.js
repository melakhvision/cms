videojs.addLanguage('en', {
  "Share": "Share",
  "Direct Link": "Direct Link",
  "Embed Code": "Embed Code",
  "Copy": "Copy",
  "Copied": "Copied"
});